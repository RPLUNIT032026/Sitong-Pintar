const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const defaultBins = [
  {id:'T-001',name:'Tong 01',location:'Halaman Depan',capacity:35},
  {id:'T-002',name:'Tong 02',location:'Area Parkir',capacity:78},
  {id:'T-003',name:'Tong 03',location:'Kantin',capacity:92},
  {id:'T-004',name:'Tong 04',location:'Taman',capacity:20},
  {id:'T-005',name:'Tong 05',location:'Gedung A',capacity:85},
  {id:'T-006',name:'Tong 06',location:'Gedung B',capacity:96},
  {id:'T-007',name:'Tong 07',location:'Perpustakaan',capacity:45},
  {id:'T-008',name:'Tong 08',location:'Laboratorium',capacity:60}
];
let bins = JSON.parse(localStorage.getItem('stp_bins') || 'null') || defaultBins;
let settings = JSON.parse(localStorage.getItem('stp_settings') || 'null') || {normal:69,warning:70};
let notifications = JSON.parse(localStorage.getItem('stp_notifications') || 'null') || [];
let history = JSON.parse(localStorage.getItem('stp_history') || 'null') || [];
let activeFilter = 'Semua';

function save(){localStorage.setItem('stp_bins',JSON.stringify(bins));localStorage.setItem('stp_settings',JSON.stringify(settings));localStorage.setItem('stp_notifications',JSON.stringify(notifications));localStorage.setItem('stp_history',JSON.stringify(history));}
function statusOf(n){return n>=90?'Penuh':n>=settings.warning?'Hampir Penuh':'Normal'}
function statusClass(s){return s==='Penuh'?'full':s==='Hampir Penuh'?'warning':'normal'}
function colorOf(s){return s==='Penuh'?'#c94e48':s==='Hampir Penuh'?'#d69a25':'#31966b'}
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2400)}
function timeNow(){return new Date().toLocaleString('id-ID',{dateStyle:'short',timeStyle:'short'})}
function addNotice(bin){const s=statusOf(bin.capacity);if(s!=='Normal'){const key=bin.id+'-'+s+'-'+Math.floor(Date.now()/60000);if(!notifications.some(n=>n.key===key)){notifications.unshift({key,title:bin.name+' – '+s,detail:`Kapasitas ${bin.capacity}% di ${bin.location}`,status:s,time:timeNow(),read:false});notifications=notifications.slice(0,30)}}}
function updateNotices(){bins.forEach(addNotice);save()}
function badge(s){return `<span class="status ${statusClass(s)}">${s}</span>`}
function render(){
  updateNotices();
  const normal=bins.filter(b=>statusOf(b.capacity)==='Normal').length;
  const warning=bins.filter(b=>statusOf(b.capacity)==='Hampir Penuh').length;
  const full=bins.filter(b=>statusOf(b.capacity)==='Penuh').length;
  $('#totalBins').textContent=bins.length;$('#normalBins').textContent=normal;$('#warningBins').textContent=warning;$('#fullBins').textContent=full;
  $('#notifBadge').textContent=notifications.filter(n=>!n.read).length;
  $('#todayDate').textContent=new Date().toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
  $('#dashboardBins').innerHTML=bins.map(b=>{const s=statusOf(b.capacity);return `<div class="bin-card"><b>${b.name}</b><div class="bin-visual" style="--fill:${b.capacity}%;--fill-color:${colorOf(s)}"></div><strong>${b.capacity}%</strong><small>${s}</small></div>`}).join('');
  $('#recentNotifications').innerHTML=notifications.slice(0,4).map(noticeHTML).join('')||'<p class="muted small">Belum ada notifikasi.</p>';
  $('#allNotifications').innerHTML=notifications.map(noticeHTML).join('')||'<p class="muted small">Belum ada notifikasi.</p>';
  $('#monitoringList').innerHTML=bins.map(b=>{const s=statusOf(b.capacity);return `<div class="monitor-row"><b>${b.name}</b><div class="progress"><span style="width:${b.capacity}%;background:${colorOf(s)}"></span></div><span class="percent">${b.capacity}%</span>${badge(s)}</div>`}).join('');
  const filtered=bins.filter(b=>activeFilter==='Semua'||statusOf(b.capacity)===activeFilter);
  $('#statusTable').innerHTML=filtered.map(b=>`<tr><td>${b.id}</td><td>${b.name}</td><td>${b.location}</td><td>${b.capacity}%</td><td>${badge(statusOf(b.capacity))}</td><td>${timeNow()}</td></tr>`).join('')||'<tr><td colspan="6">Tidak ada data.</td></tr>';
  $('#binsTable').innerHTML=bins.map(b=>`<tr><td>${b.id}</td><td>${b.name}</td><td>${b.location}</td><td>${b.capacity}%</td><td><button class="action-btn" onclick="editBin('${b.id}')">Edit</button><button class="action-btn delete" onclick="deleteBin('${b.id}')">Hapus</button></td></tr>`).join('');
  $('#historyTable').innerHTML=history.slice(0,30).map(h=>`<tr><td>${h.time}</td><td>${h.name}</td><td>${h.location}</td><td>${h.capacity}%</td><td>${badge(h.status)}</td></tr>`).join('')||'<tr><td colspan="5">Belum ada riwayat. Riwayat tercatat saat data tong disimpan.</td></tr>';
  drawChart();
}
function noticeHTML(n){return `<div class="notice ${statusClass(n.status)}"><div class="notice-icon">${n.status==='Penuh'?'🔴':'🟡'}</div><div><b>${n.title}</b><p>${n.detail} · ${n.time}</p></div></div>`}
function navigate(page){$$('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+page));$$('.nav-link').forEach(b=>b.classList.toggle('active',b.dataset.page===page));const active=$(`.nav-link[data-page="${page}"]`);$('#pageTitle').textContent=active?active.querySelector('span').textContent:'Dashboard';$('#sidebar').classList.remove('open');if(page==='history')drawChart()}
$$('.nav-link').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.page)));
$$('[data-go]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.go)));
$('#menuBtn').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
$('#loginForm').addEventListener('submit',e=>{e.preventDefault();if($('#username').value==='admin'&&$('#password').value==='admin123'){$('#loginScreen').classList.add('hidden');$('#app').classList.remove('hidden');render();toast('Berhasil masuk ke SI Tong Pintar')}else toast('Username atau password salah')});
$('#logoutBtn').addEventListener('click',()=>{$('#app').classList.add('hidden');$('#loginScreen').classList.remove('hidden')});
$$('.filter').forEach(b=>b.addEventListener('click',()=>{$$('.filter').forEach(x=>x.classList.remove('active'));b.classList.add('active');activeFilter=b.dataset.filter;render()}));
$('#clearNotif').addEventListener('click',()=>{notifications=notifications.map(n=>({...n,read:true}));save();render();toast('Notifikasi ditandai sudah dibaca')});
$('#thresholdForm').addEventListener('submit',e=>{e.preventDefault();const normal=Number($('#normalLimit').value),warning=Number($('#warningLimit').value);if(normal<1||warning<=normal||warning>99){toast('Pastikan batas peringatan lebih besar dari batas normal');return}settings={normal,warning};save();render();toast('Ambang batas berhasil disimpan')});
function resetBinForm(){$('#binForm').reset();$('#binId').value='';$('#binCapacity').value=0;$('#binFormTitle').textContent='Tambah Tong'}
$('#newBinBtn').addEventListener('click',()=>{resetBinForm();$('#binName').focus()});
$('#cancelBin').addEventListener('click',resetBinForm);
$('#binForm').addEventListener('submit',e=>{e.preventDefault();const id=$('#binId').value;const b={id:id||'T-'+String(Date.now()).slice(-5),name:$('#binName').value.trim(),location:$('#binLocation').value.trim(),capacity:Number($('#binCapacity').value)};if(id){bins=bins.map(x=>x.id===id?b:x)}else bins.push(b);history.unshift({...b,status:statusOf(b.capacity),time:timeNow()});addNotice(b);save();render();resetBinForm();toast('Data tong berhasil disimpan')});
window.editBin=id=>{const b=bins.find(x=>x.id===id);if(!b)return;$('#binId').value=b.id;$('#binName').value=b.name;$('#binLocation').value=b.location;$('#binCapacity').value=b.capacity;$('#binFormTitle').textContent='Edit '+b.name;$('#binForm').scrollIntoView({behavior:'smooth',block:'center'})};
window.deleteBin=id=>{if(!confirm('Hapus data tong ini?'))return;bins=bins.filter(b=>b.id!==id);save();render();toast('Data tong dihapus')};
function drawChart(){const c=$('#historyChart');if(!c||!$('#page-history').classList.contains('active'))return;const ctx=c.getContext('2d'),w=c.clientWidth||600,h=220,dpr=window.devicePixelRatio||1;c.width=w*dpr;c.height=h*dpr;ctx.scale(dpr,dpr);ctx.clearRect(0,0,w,h);ctx.strokeStyle='#e8eef2';ctx.fillStyle='#8795a3';ctx.font='10px Inter, sans-serif';for(let i=0;i<=4;i++){let y=15+i*42;ctx.beginPath();ctx.moveTo(32,y);ctx.lineTo(w-10,y);ctx.stroke();ctx.fillText(100-i*25,4,y+3)}let vals=history.slice(0,8).reverse().map(x=>x.capacity);if(vals.length<2)vals=[30,38,44,52,58,65,70];const step=(w-55)/(vals.length-1);ctx.beginPath();vals.forEach((v,i)=>{const x=35+i*step,y=183-v*1.55;if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y)});ctx.strokeStyle='#557b96';ctx.lineWidth=2.5;ctx.stroke();vals.forEach((v,i)=>{const x=35+i*step,y=183-v*1.55;ctx.beginPath();ctx.arc(x,y,3,0,Math.PI*2);ctx.fillStyle='#557b96';ctx.fill()})}
$('#normalLimit').value=settings.normal;$('#warningLimit').value=settings.warning;
render();
