# SI TONG PINTAR – Web App

Aplikasi web demo Digital Twin Monitoring Tong Sampah Otomatis.

## Menjalankan aplikasi
1. Ekstrak file ZIP.
2. Buka folder `si_tong_pintar_web`.
3. Klik dua kali `index.html`, atau jalankan dengan ekstensi Live Server di Visual Studio Code.

## Login demo
- Username: `admin`
- Password: `admin123`

## Fitur
- Dashboard ringkasan tong
- Visualisasi digital twin sederhana
- Monitoring kapasitas dan status
- Notifikasi
- Riwayat monitoring dan grafik
- Pengaturan ambang batas
- CRUD data tong
- Penyimpanan data demo di LocalStorage browser

## Catatan
Versi ini adalah prototype frontend. Data kapasitas masih dimasukkan melalui form dan disimpan di browser perangkat yang digunakan. Belum terhubung ke sensor IoT, database server, atau sistem autentikasi produksi.

Untuk dijadikan APK Android, proyek web ini dapat dilanjutkan dengan Capacitor atau Trusted Web Activity setelah versi web dan backend siap.
